# Program name: KASKIE_SIERRA_M03-PizzaProject.py
# Author: Sierra Kaskie
# Date: 4/12/2022
# Summary: Create a system for a guest/user/customer to use to order pizza,
# Including what type of pizza, if they would like to add more food items or soda,
# how much the pizza costs in total plus tax, and the tip included with the order for
# delivery IF selected. All food items are optional and do not require anyone to have to get all 3
# types of items.
# Variables:
#   menuItems: 
#       pizzaTypes: file with type of pizza the customer selects. (string)
#       foodExtras: file with type of additional food items such as "breadsticks" the user would like to add (string)
#       softDrinks: file with type of two-liter soda the user would like to add. (string)
#   index: the index of each individual .txt file for every menu item seperately
#       order(1, 2, 3): allows input from user to order food (int)
#       item: name of item (string)
#       price: price of item (int)
#   total: all of the pizza, additional food items, and two liter prices added together (int)
#       tax: the increment used to add tax to the total. (int)
#       tip: extra money given to the driver for delivery IF picked. (int)

# Display each type of item by reading from .txt files.
open('Menu_Items')
open('pizzaTypes')
f.read()
open('foodExtras')
f.read()
open('softDrinks')
f.read()

# Now make a class of each list of items.
# Make a class for pizzaTypes.
class pizzaTypes():

    def __init__(order, item, price):

        def order1(item):
            return self.item


# Make a class for foodExtras.
        def order2(item):
            return self.item

# Make a class for softDrinks.
        def order3(item):
            return self.item
def main():
    # Add user input for order1 for pizza type.
    input = ("Y", "N")
    order1 = int(pizzaTypes)
    index = index + 1
    if input == "Y":
        print(input("Would you like a pizza?: ", answer))
        print(input("Ok, please enter the number for the type of pizza you want: ", order1))
        order1 = int(input)
        print("Ok, one second...")
    else:
        input(answer) == "N"
        print("Ok, one second...")

    # Add user input for order2 for sides/extras.
    input = ("Y", "N")
    order2 = int(foodExtras)
    index = index + 1
    if input(answer) == "Y":
        print(input("Would you like any extras?: "))
        print(input("Ok, please enter the number for the type of extra you want: ", order2))
        order2 = int(input)
        print("Ok, one second...")
    else:
        input == "N"
        print("Ok, one second...")

    # Add user input for order 3 for soft drinks.
    input = ("Y", "N")
    order3 = int(softDrinks)
    index = index + 1
    if input == "Y":
        print(input("Would you like any soft drinks?: ", answer))
        print(input("Ok, please enter the number for the type of soft drink you want: ", order3))
        order3 = int(input)
        print("Ok, one second...")
    else:
        input(answer) == "N"
        print("Ok, one second...")

