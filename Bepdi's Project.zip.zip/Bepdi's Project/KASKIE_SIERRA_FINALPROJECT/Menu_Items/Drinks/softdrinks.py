# Add soft drink items to the list.
order2 = index1()

index1 = [1, 2, 3, 4, 5]
itemName = name
itemPrice = price

print()
print(order, item, price)

# Print a list of food items for the user to purchase.
print()
print(order, "1", item, "Fizz Bizz", price "$1.25")
print(order, "2", item, "Chartreuse Grape", price, "$2.00")
print(order, "3", item, "Razz Apple", price, "$2.15")
print(order, "4", item, "Neo Kola", price, "$1.00")
print(order, "5", item, "Marsh Gourmet Choco Soda", price, "$3.50")

print()
print("%-20d%-20s%-20.2f" % (order, item, price))