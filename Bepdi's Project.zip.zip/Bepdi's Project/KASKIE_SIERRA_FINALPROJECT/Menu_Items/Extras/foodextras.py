# Add the food extras items to the list.
order3 = index2()

index2 = [1, 2, 3, 4]
itemName = item
itemPrice = price

print()
print(order, item, price)

# print items for the user to purchase.
print()
print(order, "1", item, "Wacky Wraps", price, "$1.00")
print(order, "2", item, "Pretzel Sticks", price, "$1.00")
print(order, "3", item, "Cherry Pastry", price, "$2.25")
print(order, "4", item, "Apple Dumpling Cake", price, "$2.50")

print()
print("%-20d%-20s%-20.2f" % (order, item, price))