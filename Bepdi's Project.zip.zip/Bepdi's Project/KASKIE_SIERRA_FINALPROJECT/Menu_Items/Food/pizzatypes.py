# Add pizza types to the list.
order1 = index()

index = [1, 2, 3, 4, 5, 6, 7]
itemName = item
itemPrice = price

print()
print(order, item, price)

# Print items for the user to purchase.
print()
print(order, "1", item, "Mushtop Twist", price, "$15.00")
print(order, "2", item, "Sourdough N Turkey", price, "$12.00")
print(order, "3", item, "Ham-a-Slam", price, "$10.00")
print(order, "4", item, "Pineapple Paradise", price, "$10.00")
print(order, "5", item, "Omeleto", price, "$18.00")
print(order, "6", item, "Peppers Peppers Peppers", price, "$20.00")
print(order, "7", item, "Thin Slice", price, "$9.00")

print()
print("%-20d%-20s%-20.2f" % (order, item, price))